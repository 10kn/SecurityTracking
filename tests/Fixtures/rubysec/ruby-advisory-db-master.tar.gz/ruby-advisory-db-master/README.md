# Ruby Advisory Database

The Ruby Advisory Database is a community effort to compile all security
advisories that are relevant to Ruby libraries.
We expect others to create the data, such as getting CVE's, GHSA's,
OSVDB's, cvss', or original vulnerability information.
More details at [HERE](docs/external-data-improvements.md).

You can check your own Gemfile.locks against this database by using
[bundler-audit].

## Support Ruby Security!

Do you know about a vulnerability that isn't listed in this database? Open an
issue or submit a PR.

## Directory Structure

The database is a list of directories that match the names of Ruby libraries on
[rubygems.org]. Within each directory are one or more advisory files
for the Ruby library. These advisory files are named using
the advisories' [CVE] or [GHSA] or [OSVDB] (legacy) identifier number.

```
gems/:
  actionpack/:
    CVE-2014-0130.yml  CVE-2014-7818.yml  CVE-2014-7829.yml  CVE-2015-7576.yml
    CVE-2015-7581.yml  CVE-2016-0751.yml  CVE-2016-0752.yml
rubies/:
  jruby/:
    ...
  mruby/:
    ...
  ruby/:
    ...
```

### `gems/`

The `gems/` directory contains sub-directories that match the names of the Ruby
libraries on [rubygems.org]. Within each directory are one or more advisory
files for the Ruby library. These advisory files are named using the
advisories' [CVE] or [GHSA] ID.

### `rubies/`

The `rubies/` directory contains sub-directories for each Ruby implementation.
Within each directory are one or more advisory files for the Ruby
implementation. These advisory files are named using the advisories' [CVE]
or [GHSA] ID.

## Examples

Each advisory file contains the advisory information in [YAML] format.
Here are some example advisories:

### `gems/actionpack/CVE-2023-22795.yml`

```yaml
---
gem: actionpack
cve: 2023-22795
ghsa: 8xww-x3g3-6jcv
url: https://github.com/rails/rails/releases/tag/v7.0.4.1
title: ReDoS based DoS vulnerability in Action Dispatch
date: 2023-01-18
description: |
  There is a possible regular expression based DoS vulnerability in Action
  Dispatch related to the If-None-Match header. This vulnerability has been
  assigned the CVE identifier CVE-2023-22795.

  Versions Affected: All
  Not affected: None
  Fixed Versions: 6.1.7.1, 7.0.4.1

  # Impact

  A specially crafted HTTP If-None-Match header can cause the regular
  expression engine to enter a state of catastrophic backtracking, when on a
  version of Ruby below 3.2.0. This can cause the process to use large amounts
  of CPU and memory, leading to a possible DoS vulnerability All users running
  an affected release should either upgrade or use one of the workarounds
  immediately.

  # Workarounds

  We recommend that all users upgrade to one of the FIXED versions. In the
  meantime, users can mitigate this vulnerability by using a load balancer or
  other device to filter out malicious If-None-Match headers before they reach
  the application.

  Users on Ruby 3.2.0 or greater are not affected by this vulnerability.
patched_versions:
  - "~> 5.2.8"
  - "~> 6.1.7, >= 6.1.7.1"
  - ">= 7.0.4.1"
```

### `rubies/ruby/CVE-2022-28739.yml`

```yaml
---
engine: ruby
cve: 2022-28739
url: https://www.ruby-lang.org/en/news/2022/04/12/buffer-overrun-in-string-to-float-cve-2022-28739/
title: Buffer overrun in String-to-Float conversion
date: 2022-04-12
description: |
  A buffer-overrun vulnerability is discovered in a conversion algorithm from a
  String to a Float. This vulnerability has been assigned the CVE identifier
  CVE-2022-28739. We strongly recommend upgrading Ruby.

  Due to a bug in an internal function that converts a String to a Float, some
  conversion methods like Kernel#Float and String#to_f could cause buffer
  over-read. A typical consequence is a process termination due to segmentation
  fault, but in a limited circumstances, it may be exploitable for illegal
  memory read.

  Please update Ruby to 2.6.10, 2.7.6, 3.0.4, or 3.1.2.
patched_versions:
  - ~> 2.6.10
  - ~> 2.7.6
  - ~> 3.0.4
  - '>= 3.1.2'
```

## YAML Schema

### `gems`

* `gem` \[String\] (required): Name of the affected gem.
* `library` \[String\] (optional): Name of the ruby library which the
  affected gem belongs to.
* `framework` \[String\] (optional): Name of the framework which the
  affected gem belongs to. (e.g. rails)
* `platform` \[String\] (optional): If this vulnerability is platform-specific,
  name of platform this vulnerability affects (e.g. jruby)
* `cve` \[String\] (optional): Common Vulnerabilities and Exposures (CVE) ID.
* `osvdb` \[Integer\] (optional): Open Sourced Vulnerability Database (OSVDB) ID.
* `ghsa` \[String\] (optional): GitHub Security Advisory (GHSA) ID.
* `url` \[String\] (required): The URL to the full advisory.
* `title` \[String\] (required): The title of the advisory or individual
  vulnerability. It must be a single line sentence.
  * Line wrap `title:` field at 80.
* `date` \[Date\] (required): The public disclosure date of the advisory.
* `description` \[String\] (required): One or more paragraphs describing the
  vulnerability. It may contain multiple paragraphs.
  * Used `description: |` if it is more than one sentence/line.
  * Line wrap `descriptions:` field at 80.
  * Do not include "POC", "PoC", or "Proof of Concept" heading sections
    (any casing) in the `description:` field.
  * Not use "\n" or "%" in `description:` field.
* `cvss_v2` \[Float\] (optional): The [CVSSv2] score for the vulnerability.
* `cvss_v3` \[Float\] (optional): The [CVSSv3] score for the vulnerability.
* `cvss_v4` \[Float\] (optional): The [CVSSv4] score for the vulnerability.
* `unaffected_versions` \[Array\<String\>\] (optional): The version requirements for the
  unaffected versions of the Ruby library.
  * `unaffected_versions` version ranges must be quoted (ex: `">= 1.2.3"`).
* `patched_versions` \[Array\<String\>\] (optional): The version requirements
  for the patched versions of the Ruby library.
  * `patched_versions version ranges must be quoted (ex: `">= 1.2.3"`).
  * Omit `patched_versions:` if you have no patched version identifiers.
* `related` \[Hash\<Array\<String\>\>\] (optional): Sometimes an advisory
  references many urls and other identifiers. Supported keys:
  `cve`, `ghsa`, `osvdb`, and `url`
   * All supported keys are 4 blanks from left margin.
   * `cve`, `ghsa`, and `osvdb` related fields are not URLs.
* `notes` \[String\] (optional): Internal notes regarding the vulnerability's
  inclusion in this database.

### `rubies`

* `engine` \[`ruby` | `mruby` | `jruby` | `truffleruby`\] (required): Name
  of the affected Ruby implementation.
* `platform` \[String\] (optional): If this vulnerability is platform-specific,
  name of platform this vulnerability affects (e.g. jruby)
* `cve` \[String\] (optional): Common Vulnerabilities and Exposures (CVE) ID.
* `osvdb` \[Integer\] (optional): Open Sourced Vulnerability Database (OSVDB) ID.
* `ghsa` \[String\] (optional): GitHub Security Advisory (GHSA) ID.
* `url` \[String\] (required): The URL to the full advisory.
* `title` \[String\] (required): The title of the advisory or individual
  vulnerability. It must be a single line sentence.
  * Line wrap `title:` field at 80.
* `date` \[Date\] (required): The public disclosure date of the advisory.
* `description` \[String\] (required): One or more paragraphs describing the
  vulnerability. It may contain multiple paragraphs.
  * Used `description: |` (not `|-`) if it is more than one sentence/line.
  * Line wrap `descriptions:` field at 80.
  * Not use "\n" or "%" in `description:` field.
  * Do not include "POC", "PoC", or "Proof of Concept" heading sections
    (any casing) in the `description:` field.
* `cvss_v2` \[Float\] (optional): The [CVSSv2] score for the vulnerability.
* `cvss_v3` \[Float\] (optional): The [CVSSv3] score for the vulnerability.
* `cvss_v4` \[Float\] (optional): The [CVSSv4] score for the vulnerability.
* `unaffected_versions` \[Array\<String\>\] (optional): The version requirements
  for the unaffected versions of the Ruby implementation.
  * Field `unaffected_versions` are 2 blanks from left margin.* `cve`, `ghsa`, and `osvdb` related fields are not URLs.
* `patched_versions` \[Array\<String\>\] (optional): The version requirements
  for the patched versions of the Ruby implementation.
  * `patched_versions`/`unaffected_versions` version ranges must be quoted
     (ex: `">= 1.2.3"`).
  * Field `patched_versions`are 2 blanks from left margin.
  * Omit patched_versions: if you have no patched version identifiers.
* `related` \[Hash\<Array\<String\>\>\] (optional): Sometimes an advisory
  references many urls and other identifiers. Supported keys:
  `cve`, `ghsa`, `osvdb`, and `url`
  * All supported keys are 4 blanks from left margin.
  * `cve`, `ghsa`, and `osvdb` related fields are not URLs.
 * `notes` \[String\] (optional): Internal notes regarding the vulnerability's
  inclusion in this database.

# General Contributing Guidelines

* Advisory file name
  * Preference is CVE or GHSA over OSVDB file naming.
  * Should be equal to root `url:` field value.
* For post-2016 advisories, use only "published" or "reserved" CVEs which are found at one of these web sites:
  * https://nvd.nist.gov/vuln/search
  * https://www.cve.org/CVERecord
* All text should be wrapped at 80 columns.
  * YAML must be indented by 2 spaces.
  * Ruby YAML does not like embedded ":" characters.
  * For more info:
    * [Github Action workflow](https://github.com/rubysec/ruby-advisory-db/blob/master/.github/workflows/ruby.yml)
* Run `rspec spec/schema_validation_spec.rb` for additional lint checks.
* Check all URLs for dead links.
  * If a URL is dead, check if https://web.archive.org has a copy, and link to that.

## Tests

Prior to submitting a pull request, run the tests:

```shell
bundle install
bundle exec rspec
```

## GitHub Security Advisory Sync (GHSA)

 * The usual GHSA/SYNC workflow is:
   1. Run "GH_API_TOKEN=`GITHUB_TOKEN_VALUE` bundle exec rake sync_github_advisories" ruby script.
      - The rake task will write YAML files for any missing advisories.
        - Then it runs "./lib/rad-ignores.sh" shell script to
          ignore duplicate advisories.
        - Then it runs "yamllint" for all gems and rubies yml files.
      - More details follow this paragraph.

   2. Run "rake" to run the lint checks.

   3. If new or modified advisories, submit a PR to the repo.
   4. CAVEAT: Between steps 2 and 5, you might need to manually edit the files.

There is a script that will create initial YAML files for RubyGem advisories
which are in the [GitHub Security Advisory API], but are not already in this
dataset. This script can be periodically run to ensure this repo has all the
data that is present in the GitHub Security Advisory data.

The GitHub Security Advisory API requires a token to access it.

* It can be a completely scope-less token (recommended); it does not require any
  permissions at all.
* Get yours at: https://github.com/settings/tokens

To run the GitHub Security Advisory sync to retrieve all advisories, start by executing
the rake task:

```shell
GH_API_TOKEN="your GitHub API Token" bundle exec rake sync_github_advisories
```

Or, to only retrieve advisories for a single gem:

```shell
GH_API_TOKEN="your GitHub API Token" bundle exec rake sync_github_advisories[gem_name]
```

## Rails LTS

The maintainers of [Rails LTS] have [asked us not to track the Rails LTS versions][PR-847].
If you are using [Rails LTS] and [bundler-audit], it is advised that you should
add the [List of CVEs addressed by Rails LTS] to your `.bundler-audit.yml` file
under `ignore:`.

[Rails LTS]: https://railslts.com/
[List of CVEs addressed by Rails LTS]: https://makandracards.com/railslts/474590-list-cves-addressed-rails-lts
[PR-847]: https://github.com/rubysec/ruby-advisory-db/pull/847

## Policy on Generative AI Contributions

To safeguard project security and respect our maintainers' volunteer time, a human-in-the-loop is strictly required for all submissions. While AI tools are permitted as assistants, contributors must personally review, understand, and take full responsibility for their work. Any contributions that appear to be unreviewed machine output will be closed immediately, and repeat offenders will be banned from the project and reported.

## Credits

Please see [CONTRIBUTORS.md].

This database also includes data from the [Open Sourced Vulnerability Database][OSVDB]
developed by the Open Security Foundation (OSF) and its contributors.

[rubygems.org]: https://rubygems.org/
[bundler-audit]: https://github.com/rubysec/bundler-audit
[CVE]: https://cve.mitre.org/
[OSVDB]: https://en.wikipedia.org/wiki/Open_Source_Vulnerability_Database
[GHSA]: https://help.github.com/en/articles/about-maintainer-security-advisories
[GitHub Security Advisory API]: https://developer.github.com/v4/object/securityadvisory/
[CVSSv2]: https://www.first.org/cvss/v2/guide
[CVSSv3]: https://www.first.org/cvss/v3.1/user-guide
[CVSSv4]: https://www.first.org/cvss/v4.0/user-guide
[YAML]: http://www.yaml.org/
[CONTRIBUTORS.md]: https://github.com/rubysec/ruby-advisory-db/blob/master/CONTRIBUTORS.md
